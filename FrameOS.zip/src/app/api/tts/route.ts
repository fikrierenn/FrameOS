import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import https from 'https';

const OPENAI_API_KEY = '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';

// SSL bypass for development
const httpsAgent = new https.Agent({
  rejectUnauthorized: false,
});

const openai = new OpenAI({
  apiKey: OPENAI_API_KEY,
  httpAgent: httpsAgent,
});

export async function POST(request: NextRequest) {
  try {
    const { text, voice = 'alloy', speed = 1.0 } = await request.json();

    if (!text) {
      return NextResponse.json(
        { error: 'Text is required' },
        { status: 400 }
      );
    }

    console.log('🎙️ TTS Request:', { textLength: text.length, voice, speed });

    // OpenAI TTS API çağrısı
    const mp3 = await openai.audio.speech.create({
      model: 'tts-1',
      voice: voice as 'alloy' | 'echo' | 'fable' | 'onyx' | 'nova' | 'shimmer',
      input: text,
      speed: speed,
    });

    // Audio buffer'ı al
    const buffer = Buffer.from(await mp3.arrayBuffer());

    console.log('✅ TTS Success:', { audioSize: buffer.length });

    // Audio dosyasını döndür
    return new NextResponse(buffer, {
      headers: {
        'Content-Type': 'audio/mpeg',
        'Content-Length': buffer.length.toString(),
      },
    });
  } catch (error: any) {
    console.error('❌ TTS Error:', {
      message: error.message,
      status: error.status,
      code: error.code,
      type: error.type,
      stack: error.stack,
    });
    
    return NextResponse.json(
      { 
        error: 'TTS generation failed', 
        details: error.message,
        status: error.status,
        code: error.code,
        type: error.type,
      },
      { status: 500 }
    );
  }
}
